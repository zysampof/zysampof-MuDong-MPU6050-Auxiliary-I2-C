#ifndef __NINEAXIS_H__
#define __NINEAXIS_H__


void NineAxis_WriteReg(uint8_t RegAddress, uint8_t Data);
uint8_t NineAxis_ReadReg(uint8_t RegAddress);
uint8_t MPU6050_GetID(void);
void MPU6050_Init(void);
void HMC5883L_Init(void);
void MPU6050_PassMode(void);
void MPU6050_MasMode(void);
void MPU6050_SlaveRead(void);
void NineAxis_GetData(int16_t *AccX, int16_t *AccY, int16_t *AccZ, 
						int16_t *GyroX, int16_t *GyroY, int16_t *GyroZ,
							int16_t *GaX, int16_t *GaY, int16_t *GaZ);
float EMA(float rawValue, float filteredValue);

#endif
